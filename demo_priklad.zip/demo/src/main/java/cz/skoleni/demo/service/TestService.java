package cz.skoleni.demo.service;

import org.springframework.stereotype.Service;

/**
 * TODO javadoc
 *
 * @author Radek Novotny
 * @created on 12. 01. 2019
 */
@Service
public class TestService {


    public Integer secti(int a, int b) {
        return a + b;
    }


}
