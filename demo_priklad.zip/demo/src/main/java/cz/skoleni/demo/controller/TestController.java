package cz.skoleni.demo.controller;

import cz.skoleni.demo.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Test controller
 *
 */
@RestController
public class TestController {


    @Autowired
    private TestService service;

    @GetMapping("/{cislo1}/{cislo2}")
    @ResponseBody
    public Integer secti(@PathVariable("cislo1") Integer a, @PathVariable("cislo2") Integer b) {
        return service.secti(a, b);
    }


    @GetMapping("/{input}")
    @ResponseBody
    public String showme(@PathVariable("input") String input) {
        return "POSLAL JSI: " + input;
    }



}
